from django.db import models

class UserRole(models.Model):
    user_id=models.IntegerField()
    user_name=models.CharField(max_length=32)
    user_role = models.CharField(max_length=32)
