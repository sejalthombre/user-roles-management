from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from.forms import UserRoleForm
from.models import UserRole


def add_userrole(request):
    if request.method=="POST":
        form=UserRoleForm(request.POST)
        if form.is_valid():
            form.save()
            # return HttpResponse("user Role Added")
            return redirect("/seller/show/")
    template_name="UserRoleApp/add_userrole.html"
    form=UserRoleForm()
    context={"form":form}
    return render(request,template_name,context)
@login_required(login_url="/auth/login/")
def show_userrole(request):
    template_name = "UserRoleApp/show_userrole.html"
    role_obj=UserRole.objects.all()
    context = {"role_obj": role_obj}
    return render(request, template_name, context)

def update_userrole(request,i):
    rol_obj=UserRole.objects.get(id=i)
    if request.method =="POST":
        form=UserRoleForm(request.POST, instance=rol_obj)
        if form.is_valid():
            form.save()
            return redirect("/seller/show/")
    template_name="UserRoleApp/add_userrole.html"
    form=UserRoleForm(instance=rol_obj)
    context={"form":form}
    return render(request, template_name, context)

def delete_userrole(request,j):
    rol_obj = UserRole.objects.get(id=j)
    rol_obj.delete()
    return redirect("/seller/show")

